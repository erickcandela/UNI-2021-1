# GAPSI TEST: API PRODUCTS

## Database script 
file in src/main/resources/script.sql

## API details
swagger file in src/main/resources/swagger.yaml

## POSTMAN TESTS
https://www.getpostman.com/collections/1329f254f2317f36979a

<br>
<hr>
<strong>Steps to deploy in localhost</strong>
<hr>

## Gradle clean and build
gradle clean build 

## Run project
java -jar build/libs/api-products-0.0.1-SNAPSHOT.jar server


