package com.coviddetector.api.dto;

import lombok.Data;

@Data
public class CovidDetectorParams {
    String method;
    Integer sexo;
    Integer intubado;
    Integer neumonia;
    Integer edad;
    Integer embarazo;
    Integer diabetes;
    Integer enfermedadesPulmonares;
    Integer asma;
    Integer inmunosupresion;
    Integer hipertension;
    Integer otraEnfermedad;
    Integer cardiovascular;
    Integer obesidad;
    Integer cronicaRenal;
    Integer tabaco;
    Integer otroContactoCovid;
    Integer covidServEvidRapi;
    String result;

    @Override
    public String toString() {
        return "1," + sexo +
                ",1,099-99-99,099-99-99,099-99-99" +
                "," + intubado +
                "," + neumonia +
                "," + edad +
                "," + embarazo +
                "," + diabetes +
                "," + enfermedadesPulmonares +
                "," + asma +
                "," + inmunosupresion +
                "," + hipertension +
                "," + otraEnfermedad +
                "," + cardiovascular +
                "," + obesidad +
                "," + cronicaRenal +
                "," + tabaco +
                "," + otroContactoCovid +
                "," + covidServEvidRapi +
                ",?";
    }
}
