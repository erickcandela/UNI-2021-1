package com.coviddetector.api.api;


import com.coviddetector.api.dto.CovidDetectorParams;
import com.coviddetector.api.service.solutions.*;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

@RestController
@RequestMapping("/v1/covid-detector")
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJAXRSSpecServerCodegen", date = "2021-06-19T03:50:40.413Z[GMT]")
@CrossOrigin
@Slf4j
public class CovidDetectorApi {

    @RequestMapping(value = "",
            produces = { "application/json" },
            method = RequestMethod.POST)
    public ResponseEntity<?> getResponse(
            @ApiParam(value = "Params", required = true) @Valid @RequestBody CovidDetectorParams body
    ) throws IOException {
        ISolutionMethod iSolutionMethod = new SolutionBayesNet();
        String directory = "/Users/manuelsanchez/Desktop/ia-dataset/";

        String fileModel = directory + "model/j48.model";

        String original = "evaluate/default-evaluate.arff";
        String uuid = "evaluate/evaluate.arff";

        switch (body.getMethod()) {
            case "J48":
                log.info("METHOD J48");
                iSolutionMethod = new SolutionJ48();
                fileModel = directory + "model/j48.model";
                break;
            case "BAYES":
                log.info("METHOD BAYES");
                iSolutionMethod = new SolutionBayesNet();
                fileModel = directory + "model/bayes.model";
                break;
            case "RANDOM":
                log.info("METHOD RANDOM");
                iSolutionMethod = new SolutionRandomForest();
                fileModel = directory + "model/random-forest.model";
                break;
            case "SVM":
                log.info("SVM");
                iSolutionMethod = new SolutionSVM();
                fileModel = directory + "model/svm.model";
                break;
        }

        String parameterNameFileTraining = directory + uuid;
        Files.copy(Paths.get(directory + original), Paths.get(parameterNameFileTraining), StandardCopyOption.REPLACE_EXISTING);
        FileWriter myWriter = new FileWriter(parameterNameFileTraining, true);
        myWriter.write(body.toString());
        myWriter.close();

        body.setResult(iSolutionMethod.evaluate(parameterNameFileTraining, fileModel));

        return new ResponseEntity<>(body, HttpStatus.OK);
    }

}
