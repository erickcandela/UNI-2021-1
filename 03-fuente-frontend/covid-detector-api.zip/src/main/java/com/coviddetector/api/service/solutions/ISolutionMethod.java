package com.coviddetector.api.service.solutions;

public interface ISolutionMethod {
    public String evaluate(String parameterNameFileTraining,
                         String parameterNameFileModel);
}
